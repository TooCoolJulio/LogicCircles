# Instructions
To clone this repository you need to complete the following steps.

## Step 1
If you haven't already, create a project folder to house all of your unity projects in

## Step 2
Open Bash and enter the project folder using the command line

Example: `cd development/unityprojects`

## Step 3
Clone the repository using the commands below

`git clone https://github.com/ikarskarn/LogicCircles.git `

## Step 4
To ensure that it worked, try opening the project with Unity Hub